<div class="nav-header">
    <a href="#" class="brand-logo">
     <img src="{{ asset('logo/logoAlfitri.png')}}" alt="" style="height: 70px;  margin-left: auto;
     margin-right: auto;">

    </a>
    <div class="nav-control">
        <div class="hamburger">
            <span class="line"></span><span class="line"></span><span class="line"></span>
        </div>
    </div>
</div>